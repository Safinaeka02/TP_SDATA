<?php
header('Content-Type: application/json');

// Simple authentication (untuk production gunakan database)
$validAccounts = [
    ['username' => 'admin', 'password' => 'admin123', 'role' => 'admin'],
    ['username' => 'guru1', 'password' => 'guru123', 'role' => 'guru'],
    ['username' => 'siswa1', 'password' => 'siswa123', 'role' => 'siswa']
];

$input = json_decode(file_get_contents('php://input'), true);
$username = $input['username'] ?? '';
$password = $input['password'] ?? '';
$role = $input['role'] ?? '';

$authenticated = false;
foreach ($validAccounts as $account) {
    if ($account['username'] === $username && 
        $account['password'] === $password && 
        $account['role'] === $role) {
        $authenticated = true;
        break;
    }
}

echo json_encode([
    'success' => $authenticated,
    'message' => $authenticated ? 'Login berhasil' : 'Username atau password salah'
]);
?>
