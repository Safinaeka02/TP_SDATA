<?php
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$dataFile = '../data/school_data.json';

// Create directory if not exists
if (!is_dir('../data')) {
    mkdir('../data', 0777, true);
}

// Save to file
file_put_contents($dataFile, json_encode($data, JSON_PRETTY_PRINT));

echo json_encode(['success' => true]);
?>
