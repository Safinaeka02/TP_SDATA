# Sistem Manajemen Sekolah Terpadu

Aplikasi web lengkap untuk mengelola seluruh aspek operasional sekolah dengan interface modern dan responsif.

## Fitur Utama

- **Dashboard**: Statistik real-time (total siswa, guru, kelas, dan persentase kehadiran)
- **Manajemen Siswa**: Tambah, edit, hapus, dan cari data siswa lengkap dengan NIS dan kontak
- **Manajemen Guru**: Kelola data guru, mata pelajaran, dan informasi kontak
- **Manajemen Kelas**: Atur kelas, wali kelas, kapasitas siswa, dan ruangan
- **Sistem Absensi**: Input kehadiran siswa per tanggal dengan status (Hadir, Sakit, Izin, Alpa)
- **Manajemen Nilai**: Input nilai siswa dengan perhitungan grade otomatis (A-E)
- **Jadwal Pelajaran**: Buat jadwal harian dengan guru, mata pelajaran, dan ruangan
- **Authentikasi**: Login dengan role berbeda (Admin, Guru, Siswa)

## Teknologi

- **Frontend**: HTML5, CSS3, JavaScript Vanilla (tanpa framework)
- **Backend**: PHP (tanpa database SQL)
- **Penyimpanan Data**: JSON file + LocalStorage
- **Icons**: Font Awesome 6.4

## Instalasi & Cara Jalankan

### Requirement
- Web Server (Apache/XAMPP/WAMP)
- PHP 7.0+
- Browser modern

### Langkah Instalasi

1. **Extract file** ke folder web server (htdocs untuk XAMPP)
```bash
cd /xampp/htdocs
unzip sistem-sekolah.zip
```

2. **Jalankan XAMPP** dan pastikan Apache aktif

3. **Akses aplikasi** melalui browser:
```
http://localhost/sistem-sekolah/
```

4. **Login** menggunakan akun demo:
   - Username: `admin`
   - Password: `admin123`
   - Role: `Admin`

## Demo Data

File `data/school_data.json` sudah berisi data sampel:
- 2 siswa (Ahmad Ridho, Siti Nurhaliza)
- 2 guru (Budi Santoso, Ani Wijaya)
- 2 kelas (X-A, X-B)
- 1 jadwal pelajaran sampel

## Struktur Folder

```
sistem-sekolah/
├── index.html              (Dashboard utama)
├── login.html              (Halaman login)
├── css/
│   └── style.css          (Stylesheet utama)
├── js/
│   └── app.js             (JavaScript logic)
├── php/
│   ├── getData.php        (Ambil data dari JSON)
│   ├── saveData.php       (Simpan data ke JSON)
│   └── login.php          (Validasi login)
├── data/
│   └── school_data.json   (Data penyimpanan JSON)
├── .htaccess              (Konfigurasi Apache)
└── README.md              (File ini)
```

## Cara Penggunaan

### 1. Login
- Masukkan username, password, dan pilih role
- Demo account: admin / admin123

### 2. Dashboard
- Lihat statistik ringkasan sekolah
- Muncul otomatis setelah login

### 3. Manajemen Siswa
- Klik menu "Siswa"
- Klik tombol "Tambah Siswa" untuk input baru
- Gunakan search untuk mencari siswa
- Edit atau hapus data dengan tombol action

### 4. Manajemen Guru
- Klik menu "Guru"
- Input data guru dengan mata pelajaran
- Guru akan digunakan di jadwal dan nilai

### 5. Manajemen Kelas
- Klik menu "Kelas"
- Tambah kelas dengan wali dan kapasitas
- Kelas digunakan di siswa dan jadwal

### 6. Absensi
- Pilih kelas dan tanggal
- Klik "Muat Data" untuk lihat siswa
- Pilih status kehadiran untuk setiap siswa
- Data otomatis tersimpan

### 7. Nilai
- Pilih kelas dan mata pelajaran
- Lihat nilai siswa
- Klik "Edit" untuk update nilai
- Grade otomatis dihitung (A: 90+, B: 80+, C: 70+, D: 60+, E: <60)

### 8. Jadwal
- Klik menu "Jadwal"
- Input hari, jam, mata pelajaran, guru, kelas, ruangan
- Filter jadwal per kelas dengan dropdown

## Fitur Responsif

Aplikasi dapat diakses di:
- 🖥️ Desktop (1920px ke atas)
- 📱 Tablet (768px - 1024px)
- 📲 Mobile (< 768px)

Sidebar berubah menjadi horizontal menu di mobile, tabel scroll horizontal, dan semua form menyesuaikan.

## Catatan Penting

### Penyimpanan Data
- Data disimpan di `data/school_data.json`
- Juga di-backup ke LocalStorage browser untuk fallback
- Pastikan folder `data/` punya write permission (chmod 777)

### Keamanan
- Ini adalah aplikasi demo, gunakan untuk testing saja
- Untuk production: implementasikan database SQL, hashing password, session management
- Jangan expose file `data/` di production

### Troubleshooting

**Data tidak tersimpan?**
- Pastikan folder `data/` ada dan punya permission write
- Cek browser console untuk error messages
- Gunakan localStorage fallback jika PHP tidak bekerja

**Login tidak bisa?**
- Buka `php/login.php` dan cek akun yang tersedia
- Gunakan developer tools untuk debug

**Styling tidak muncul?**
- Clear browser cache (Ctrl+Shift+Del)
- Pastikan file `css/style.css` ada

## Pengembangan Lebih Lanjut

Fitur yang bisa ditambahkan:
- Export data ke Excel/PDF
- Email notification
- Integasi dengan sistem payment (pembayaran SPP)
- Laporan akademik detail
- API REST untuk mobile app
- Database MySQL untuk scalability

## License

MIT - Bebas digunakan untuk keperluan pendidikan dan komersial

## Support

Untuk issue atau pertanyaan, buat issue di repository atau hubungi developer.

---

**Dibuat dengan ❤️ untuk kemudahan manajemen sekolah**
