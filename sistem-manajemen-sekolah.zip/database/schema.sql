-- Create Database
CREATE DATABASE IF NOT EXISTS sekolah_db;
USE sekolah_db;

-- Users Table
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'guru', 'siswa', 'orang_tua') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Siswa Table
CREATE TABLE siswa (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nis VARCHAR(20) UNIQUE NOT NULL,
    nama VARCHAR(100) NOT NULL,
    kelas VARCHAR(20) NOT NULL,
    email VARCHAR(100),
    telp VARCHAR(20),
    alamat TEXT,
    tanggal_lahir DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Guru Table
CREATE TABLE guru (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nip VARCHAR(20) UNIQUE NOT NULL,
    nama VARCHAR(100) NOT NULL,
    mapel VARCHAR(50) NOT NULL,
    email VARCHAR(100),
    telp VARCHAR(20),
    status ENUM('Aktif', 'Cuti', 'Pensiun') DEFAULT 'Aktif',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Kelas Table
CREATE TABLE kelas (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nama VARCHAR(20) NOT NULL,
    wali_kelas VARCHAR(100),
    jumlah_siswa INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Absensi Table
CREATE TABLE absensi (
    id INT PRIMARY KEY AUTO_INCREMENT,
    siswa_id INT NOT NULL,
    tanggal DATE NOT NULL,
    status ENUM('Hadir', 'Sakit', 'Izin', 'Alpa') NOT NULL,
    catatan TEXT,
    FOREIGN KEY (siswa_id) REFERENCES siswa(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Nilai Table
CREATE TABLE nilai (
    id INT PRIMARY KEY AUTO_INCREMENT,
    siswa_id INT NOT NULL,
    mapel VARCHAR(50) NOT NULL,
    uts INT,
    uas INT,
    tugas INT,
    nilai_akhir DECIMAL(5,2),
    grade VARCHAR(1),
    FOREIGN KEY (siswa_id) REFERENCES siswa(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Jadwal Pelajaran Table
CREATE TABLE jadwal (
    id INT PRIMARY KEY AUTO_INCREMENT,
    kelas_id INT NOT NULL,
    hari VARCHAR(20) NOT NULL,
    jam_mulai TIME NOT NULL,
    jam_selesai TIME NOT NULL,
    mapel VARCHAR(50) NOT NULL,
    guru_id INT,
    ruangan VARCHAR(20),
    FOREIGN KEY (kelas_id) REFERENCES kelas(id),
    FOREIGN KEY (guru_id) REFERENCES guru(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Settings Table
CREATE TABLE settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nama_sekolah VARCHAR(200),
    alamat TEXT,
    telp VARCHAR(20),
    email VARCHAR(100),
    tahun_ajaran VARCHAR(20),
    kepala_sekolah VARCHAR(100),
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert default data
INSERT INTO users (email, password, role) VALUES
('admin@sekolah.com', SHA2('password123', 256), 'admin'),
('guru@sekolah.com', SHA2('password123', 256), 'guru'),
('siswa@sekolah.com', SHA2('password123', 256), 'siswa');

INSERT INTO kelas (nama, wali_kelas) VALUES
('X-A', 'Ibu Siti'),
('X-B', 'Pak Ahmad'),
('XI-A', 'Ibu Rina');

INSERT INTO settings (nama_sekolah, alamat, tahun_ajaran) VALUES
('SMA Negeri Digital', 'Jl. Pendidikan No. 123, Jakarta', '2024/2025');
