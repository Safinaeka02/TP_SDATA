<?php
header('Content-Type: application/json');
require_once '../config/database.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = isset($_GET['action']) ? $_GET['action'] : '';

if ($method === 'GET' && $action === 'list') {
    $sql = "SELECT * FROM siswa";
    $result = $conn->query($sql);
    
    $siswa = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $siswa[] = $row;
        }
    }
    
    echo json_encode($siswa);
}

if ($method === 'POST' && $action === 'add') {
    $data = json_decode(file_get_contents("php://input"), true);
    
    $nis = $data['nis'];
    $nama = $data['nama'];
    $kelas = $data['kelas'];
    $email = $data['email'];
    $telp = $data['telp'];
    
    $sql = "INSERT INTO siswa (nis, nama, kelas, email, telp) VALUES ('$nis', '$nama', '$kelas', '$email', '$telp')";
    
    if ($conn->query($sql) === TRUE) {
        echo json_encode(['success' => true, 'message' => 'Siswa berhasil ditambahkan']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $conn->error]);
    }
}

if ($method === 'POST' && $action === 'update') {
    $data = json_decode(file_get_contents("php://input"), true);
    
    $id = $data['id'];
    $nama = $data['nama'];
    $kelas = $data['kelas'];
    $email = $data['email'];
    
    $sql = "UPDATE siswa SET nama='$nama', kelas='$kelas', email='$email' WHERE id=$id";
    
    if ($conn->query($sql) === TRUE) {
        echo json_encode(['success' => true, 'message' => 'Siswa berhasil diperbarui']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $conn->error]);
    }
}

if ($method === 'DELETE' && $action === 'delete') {
    $data = json_decode(file_get_contents("php://input"), true);
    $id = $data['id'];
    
    $sql = "DELETE FROM siswa WHERE id=$id";
    
    if ($conn->query($sql) === TRUE) {
        echo json_encode(['success' => true, 'message' => 'Siswa berhasil dihapus']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $conn->error]);
    }
}

?>
