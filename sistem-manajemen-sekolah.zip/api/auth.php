<?php
header('Content-Type: application/json');
require_once '../config/database.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = isset($_GET['action']) ? $_GET['action'] : '';

if ($method === 'POST' && $action === 'login') {
    $data = json_decode(file_get_contents("php://input"), true);
    
    $email = $data['email'];
    $password = $data['password'];
    $role = $data['role'];
    
    // Demo authentication
    $validUsers = [
        'admin@sekolah.com' => ['password' => 'password123', 'role' => 'admin'],
        'guru@sekolah.com' => ['password' => 'password123', 'role' => 'guru'],
        'siswa@sekolah.com' => ['password' => 'password123', 'role' => 'siswa']
    ];
    
    if (isset($validUsers[$email]) && $validUsers[$email]['password'] === $password && $validUsers[$email]['role'] === $role) {
        session_start();
        $_SESSION['user'] = ['email' => $email, 'role' => $role];
        echo json_encode(['success' => true, 'message' => 'Login berhasil']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Email atau password salah']);
    }
}

if ($method === 'POST' && $action === 'logout') {
    session_start();
    session_destroy();
    echo json_encode(['success' => true, 'message' => 'Logout berhasil']);
}

?>
