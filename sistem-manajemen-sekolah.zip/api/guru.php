<?php
header('Content-Type: application/json');
require_once '../config/database.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = isset($_GET['action']) ? $_GET['action'] : '';

if ($method === 'GET' && $action === 'list') {
    $sql = "SELECT * FROM guru";
    $result = $conn->query($sql);
    
    $guru = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $guru[] = $row;
        }
    }
    
    echo json_encode($guru);
}

if ($method === 'POST' && $action === 'add') {
    $data = json_decode(file_get_contents("php://input"), true);
    
    $nip = $data['nip'];
    $nama = $data['nama'];
    $mapel = $data['mapel'];
    $email = $data['email'];
    $status = $data['status'];
    
    $sql = "INSERT INTO guru (nip, nama, mapel, email, status) VALUES ('$nip', '$nama', '$mapel', '$email', '$status')";
    
    if ($conn->query($sql) === TRUE) {
        echo json_encode(['success' => true, 'message' => 'Guru berhasil ditambahkan']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $conn->error]);
    }
}

if ($method === 'POST' && $action === 'update') {
    $data = json_decode(file_get_contents("php://input"), true);
    
    $id = $data['id'];
    $nama = $data['nama'];
    $mapel = $data['mapel'];
    $status = $data['status'];
    
    $sql = "UPDATE guru SET nama='$nama', mapel='$mapel', status='$status' WHERE id=$id";
    
    if ($conn->query($sql) === TRUE) {
        echo json_encode(['success' => true, 'message' => 'Guru berhasil diperbarui']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $conn->error]);
    }
}

if ($method === 'DELETE' && $action === 'delete') {
    $data = json_decode(file_get_contents("php://input"), true);
    $id = $data['id'];
    
    $sql = "DELETE FROM guru WHERE id=$id";
    
    if ($conn->query($sql) === TRUE) {
        echo json_encode(['success' => true, 'message' => 'Guru berhasil dihapus']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $conn->error]);
    }
}

?>
