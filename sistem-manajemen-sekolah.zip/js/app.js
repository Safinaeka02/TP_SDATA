// Data Storage (Local)
const store = {
  siswa: [],
  guru: [],
  kelas: [],
  absensi: [],
  nilai: [],
  jadwal: [],
}

// Initialize App
document.addEventListener("DOMContentLoaded", () => {
  loadAllData()
  setupEventListeners()
  updateDateTime()
  setInterval(updateDateTime, 1000)
})

// Load all data from localStorage or server
function loadAllData() {
  fetch("php/getData.php")
    .then((res) => res.json())
    .then((data) => {
      store.siswa = data.siswa || []
      store.guru = data.guru || []
      store.kelas = data.kelas || []
      store.absensi = data.absensi || []
      store.nilai = data.nilai || []
      store.jadwal = data.jadwal || []
      updateDashboard()
    })
    .catch((err) => {
      console.log("Using local storage")
      loadFromLocalStorageFallback()
    })
}

// Load from localStorage (fallback)
function loadFromLocalStorageFallback() {
  const saved = localStorage.getItem("schoolData")
  if (saved) {
    const data = JSON.parse(saved)
    Object.assign(store, data)
  }
}

// Save data
function saveData() {
  fetch("php/saveData.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(store),
  })
  saveToLocalStorage()
}

// Setup Event Listeners
function setupEventListeners() {
  document.querySelectorAll(".menu-item").forEach((btn) => {
    btn.addEventListener("click", function (e) {
      e.preventDefault()
      const menu = this.dataset.menu
      if (menu === "logout") {
        logout()
        return
      }
      switchMenu(menu)
    })
  })

  // Add buttons
  document.getElementById("addSiswaBtn")?.addEventListener("click", () => openModalSiswa())
  document.getElementById("addGuruBtn")?.addEventListener("click", () => openModalGuru())
  document.getElementById("addKelasBtn")?.addEventListener("click", () => openModalKelas())
  document.getElementById("addNilaiBtn")?.addEventListener("click", () => openModalNilai())
  document.getElementById("addJadwalBtn")?.addEventListener("click", () => openModalJadwal())
  document.getElementById("loadAbsensiBtn")?.addEventListener("click", loadAbsensiTable)

  // Search
  document.getElementById("searchSiswa")?.addEventListener("keyup", filterSiswa)
  document.getElementById("searchGuru")?.addEventListener("keyup", filterGuru)

  // Modal
  document.getElementById("modalClose")?.addEventListener("click", closeModal)
  document.getElementById("modalForm")?.addEventListener("submit", handleFormSubmit)

  // Close modal on background click
  document.getElementById("modal")?.addEventListener("click", function (e) {
    if (e.target === this) closeModal()
  })

  // Jadwal filter
  document.getElementById("kelasJadwalFilter")?.addEventListener("change", renderJadwalTable)
}

// Menu Navigation
function switchMenu(menuName) {
  document.querySelectorAll(".menu-content").forEach((el) => el.classList.remove("active"))
  document.querySelectorAll(".menu-item").forEach((el) => el.classList.remove("active"))

  document.getElementById(menuName)?.classList.add("active")
  document.querySelector(`[data-menu="${menuName}"]`)?.classList.add("active")

  // Update page title
  const titles = {
    dashboard: "Dashboard",
    siswa: "Manajemen Siswa",
    guru: "Manajemen Guru",
    kelas: "Manajemen Kelas",
    absensi: "Absensi Siswa",
    nilai: "Nilai Siswa",
    jadwal: "Jadwal Pelajaran",
  }
  document.getElementById("pageTitle").textContent = titles[menuName] || "Dashboard"

  // Load specific data
  if (menuName === "siswa") renderSiswaTable()
  if (menuName === "guru") renderGuruTable()
  if (menuName === "kelas") renderKelasGrid()
  if (menuName === "absensi") setupAbsensiFilters()
  if (menuName === "nilai") setupNilaiFilters()
  if (menuName === "jadwal") renderJadwalTable()
}

// ==================== DASHBOARD ====================
function updateDashboard() {
  document.getElementById("totalSiswa").textContent = store.siswa.length
  document.getElementById("totalGuru").textContent = store.guru.length
  document.getElementById("totalKelas").textContent = store.kelas.length

  const totalKehadiran = store.absensi.filter((a) => a.status === "Hadir").length
  const avgKehadiran = store.absensi.length > 0 ? Math.round((totalKehadiran / store.absensi.length) * 100) : 0
  document.getElementById("avgKehadiran").textContent = avgKehadiran + "%"
}

// ==================== SISWA ====================
function renderSiswaTable() {
  const tbody = document.getElementById("siswaTbody")
  tbody.innerHTML = ""

  store.siswa.forEach((siswa, idx) => {
    const row = document.createElement("tr")
    row.innerHTML = `
            <td>${siswa.nis}</td>
            <td>${siswa.nama}</td>
            <td>${siswa.kelas}</td>
            <td>${siswa.email}</td>
            <td>
                <div class="action-buttons">
                    <button class="edit-btn" onclick="editSiswa(${idx})">Edit</button>
                    <button class="delete-btn" onclick="deleteSiswa(${idx})">Hapus</button>
                </div>
            </td>
        `
    tbody.appendChild(row)
  })
}

function filterSiswa() {
  const search = document.getElementById("searchSiswa").value.toLowerCase()
  document.querySelectorAll("#siswaTbody tr").forEach((row) => {
    const text = row.textContent.toLowerCase()
    row.style.display = text.includes(search) ? "" : "none"
  })
}

function openModalSiswa(idx = null) {
  const title = idx !== null ? "Edit Siswa" : "Tambah Siswa"
  const siswa = idx !== null ? store.siswa[idx] : { nis: "", nama: "", kelas: "", email: "", telepon: "" }

  const form = `
        <div class="form-group">
            <label>NIS</label>
            <input type="text" id="nis" value="${siswa.nis}" required>
        </div>
        <div class="form-group">
            <label>Nama Lengkap</label>
            <input type="text" id="nama" value="${siswa.nama}" required>
        </div>
        <div class="form-group">
            <label>Kelas</label>
            <input type="text" id="kelas" value="${siswa.kelas}" required>
        </div>
        <div class="form-group">
            <label>Email</label>
            <input type="email" id="email" value="${siswa.email}" required>
        </div>
        <div class="form-group">
            <label>Telepon</label>
            <input type="text" id="telepon" value="${siswa.telepon || ""}">
        </div>
        <div class="form-buttons">
            <button type="submit" class="btn btn-primary">Simpan</button>
            <button type="button" class="btn btn-secondary" onclick="closeModal()">Batal</button>
        </div>
    `

  showModal(title, form, () => {
    const newSiswa = {
      nis: document.getElementById("nis").value,
      nama: document.getElementById("nama").value,
      kelas: document.getElementById("kelas").value,
      email: document.getElementById("email").value,
      telepon: document.getElementById("telepon").value,
    }

    if (idx !== null) {
      store.siswa[idx] = newSiswa
    } else {
      store.siswa.push(newSiswa)
    }
    saveData()
    renderSiswaTable()
    updateDashboard()
    closeModal()
  })
}

function editSiswa(idx) {
  openModalSiswa(idx)
}

function deleteSiswa(idx) {
  if (confirm("Yakin ingin menghapus data siswa ini?")) {
    store.siswa.splice(idx, 1)
    saveData()
    renderSiswaTable()
    updateDashboard()
  }
}

// ==================== GURU ====================
function renderGuruTable() {
  const tbody = document.getElementById("guruTbody")
  tbody.innerHTML = ""

  store.guru.forEach((guru, idx) => {
    const row = document.createElement("tr")
    row.innerHTML = `
            <td>${guru.nip}</td>
            <td>${guru.nama}</td>
            <td>${guru.mataPelajaran}</td>
            <td>${guru.email}</td>
            <td>
                <div class="action-buttons">
                    <button class="edit-btn" onclick="editGuru(${idx})">Edit</button>
                    <button class="delete-btn" onclick="deleteGuru(${idx})">Hapus</button>
                </div>
            </td>
        `
    tbody.appendChild(row)
  })
}

function filterGuru() {
  const search = document.getElementById("searchGuru").value.toLowerCase()
  document.querySelectorAll("#guruTbody tr").forEach((row) => {
    const text = row.textContent.toLowerCase()
    row.style.display = text.includes(search) ? "" : "none"
  })
}

function openModalGuru(idx = null) {
  const title = idx !== null ? "Edit Guru" : "Tambah Guru"
  const guru = idx !== null ? store.guru[idx] : { nip: "", nama: "", mataPelajaran: "", email: "", telepon: "" }

  const form = `
        <div class="form-group">
            <label>NIP</label>
            <input type="text" id="nip" value="${guru.nip}" required>
        </div>
        <div class="form-group">
            <label>Nama Lengkap</label>
            <input type="text" id="nama" value="${guru.nama}" required>
        </div>
        <div class="form-group">
            <label>Mata Pelajaran</label>
            <input type="text" id="mataPelajaran" value="${guru.mataPelajaran}" required>
        </div>
        <div class="form-group">
            <label>Email</label>
            <input type="email" id="email" value="${guru.email}" required>
        </div>
        <div class="form-group">
            <label>Telepon</label>
            <input type="text" id="telepon" value="${guru.telepon || ""}">
        </div>
        <div class="form-buttons">
            <button type="submit" class="btn btn-primary">Simpan</button>
            <button type="button" class="btn btn-secondary" onclick="closeModal()">Batal</button>
        </div>
    `

  showModal(title, form, () => {
    const newGuru = {
      nip: document.getElementById("nip").value,
      nama: document.getElementById("nama").value,
      mataPelajaran: document.getElementById("mataPelajaran").value,
      email: document.getElementById("email").value,
      telepon: document.getElementById("telepon").value,
    }

    if (idx !== null) {
      store.guru[idx] = newGuru
    } else {
      store.guru.push(newGuru)
    }
    saveData()
    renderGuruTable()
    updateDashboard()
    closeModal()
  })
}

function editGuru(idx) {
  openModalGuru(idx)
}

function deleteGuru(idx) {
  if (confirm("Yakin ingin menghapus data guru ini?")) {
    store.guru.splice(idx, 1)
    saveData()
    renderGuruTable()
    updateDashboard()
  }
}

// ==================== KELAS ====================
function renderKelasGrid() {
  const container = document.querySelector(".kelas-grid")
  container.innerHTML = ""

  store.kelas.forEach((kelas, idx) => {
    const card = document.createElement("div")
    card.className = "kelas-card"
    card.innerHTML = `
            <h3>${kelas.nama}</h3>
            <p><strong>Wali Kelas:</strong> ${kelas.waliKelas}</p>
            <p><strong>Kapasitas:</strong> ${kelas.kapasitas} siswa</p>
            <p><strong>Ruangan:</strong> ${kelas.ruangan}</p>
            <div class="action-buttons" style="margin-top: 15px;">
                <button class="edit-btn" onclick="editKelas(${idx})">Edit</button>
                <button class="delete-btn" onclick="deleteKelas(${idx})">Hapus</button>
            </div>
        `
    container.appendChild(card)
  })
}

function openModalKelas(idx = null) {
  const title = idx !== null ? "Edit Kelas" : "Tambah Kelas"
  const kelas = idx !== null ? store.kelas[idx] : { nama: "", waliKelas: "", kapasitas: "", ruangan: "" }

  const form = `
        <div class="form-group">
            <label>Nama Kelas</label>
            <input type="text" id="nama" value="${kelas.nama}" placeholder="Contoh: X-A" required>
        </div>
        <div class="form-group">
            <label>Wali Kelas</label>
            <input type="text" id="waliKelas" value="${kelas.waliKelas}" required>
        </div>
        <div class="form-group">
            <label>Kapasitas Siswa</label>
            <input type="number" id="kapasitas" value="${kelas.kapasitas}" required>
        </div>
        <div class="form-group">
            <label>Ruangan</label>
            <input type="text" id="ruangan" value="${kelas.ruangan}" placeholder="Contoh: Ruang 101" required>
        </div>
        <div class="form-buttons">
            <button type="submit" class="btn btn-primary">Simpan</button>
            <button type="button" class="btn btn-secondary" onclick="closeModal()">Batal</button>
        </div>
    `

  showModal(title, form, () => {
    const newKelas = {
      nama: document.getElementById("nama").value,
      waliKelas: document.getElementById("waliKelas").value,
      kapasitas: document.getElementById("kapasitas").value,
      ruangan: document.getElementById("ruangan").value,
    }

    if (idx !== null) {
      store.kelas[idx] = newKelas
    } else {
      store.kelas.push(newKelas)
    }
    saveData()
    renderKelasGrid()
    updateDashboard()
    closeModal()
  })
}

function editKelas(idx) {
  openModalKelas(idx)
}

function deleteKelas(idx) {
  if (confirm("Yakin ingin menghapus kelas ini?")) {
    store.kelas.splice(idx, 1)
    saveData()
    renderKelasGrid()
    updateDashboard()
  }
}

// ==================== ABSENSI ====================
function setupAbsensiFilters() {
  const kelasFilter = document.getElementById("kelasFilter")
  kelasFilter.innerHTML = '<option value="">Pilih Kelas</option>'
  store.kelas.forEach((kelas, idx) => {
    const option = document.createElement("option")
    option.value = kelas.nama
    option.textContent = kelas.nama
    kelasFilter.appendChild(option)
  })
}

function loadAbsensiTable() {
  const kelas = document.getElementById("kelasFilter").value
  const tanggal = document.getElementById("tanggalAbsensi").value

  if (!kelas || !tanggal) {
    alert("Pilih kelas dan tanggal terlebih dahulu")
    return
  }

  const tbody = document.getElementById("absensiTbody")
  tbody.innerHTML = ""

  const siswasInKelas = store.siswa.filter((s) => s.kelas === kelas)

  siswasInKelas.forEach((siswa, idx) => {
    const absensiKey = `${siswa.nis}_${tanggal}`
    const absensiData = store.absensi.find((a) => a.key === absensiKey)
    const status = absensiData?.status || ""

    const row = document.createElement("tr")
    row.innerHTML = `
            <td>${siswa.nama}</td>
            <td>
                <select onchange="updateAbsensi('${absensiKey}', this.value, '${siswa.nis}', '${tanggal}')">
                    <option value="">Pilih</option>
                    <option value="Hadir" ${status === "Hadir" ? "selected" : ""}>Hadir</option>
                    <option value="Sakit" ${status === "Sakit" ? "selected" : ""}>Sakit</option>
                    <option value="Izin" ${status === "Izin" ? "selected" : ""}>Izin</option>
                    <option value="Alpa" ${status === "Alpa" ? "selected" : ""}>Alpa</option>
                </select>
            </td>
            <td>
                <input type="text" placeholder="Keterangan" value="${absensiData?.keterangan || ""}" 
                       onchange="updateAbsensiKeterangan('${absensiKey}', this.value)">
            </td>
        `
    tbody.appendChild(row)
  })
}

function updateAbsensi(key, status, nis, tanggal) {
  const existing = store.absensi.findIndex((a) => a.key === key)
  const data = {
    key,
    nis,
    tanggal,
    status,
    keterangan: "",
  }

  if (existing > -1) {
    store.absensi[existing] = { ...store.absensi[existing], ...data }
  } else {
    store.absensi.push(data)
  }
  saveData()
}

function updateAbsensiKeterangan(key, keterangan) {
  const existing = store.absensi.find((a) => a.key === key)
  if (existing) {
    existing.keterangan = keterangan
    saveData()
  }
}

// ==================== NILAI ====================
function setupNilaiFilters() {
  const kelasFilter = document.getElementById("kelasNilaiFilter")
  kelasFilter.innerHTML = '<option value="">Pilih Kelas</option>'
  store.kelas.forEach((kelas) => {
    const option = document.createElement("option")
    option.value = kelas.nama
    option.textContent = kelas.nama
    kelasFilter.appendChild(option)
  })

  const mpFilter = document.getElementById("mataPelajaranFilter")
  mpFilter.innerHTML = '<option value="">Pilih Mata Pelajaran</option>'
  ;[...new Set(store.guru.map((g) => g.mataPelajaran))].forEach((mp) => {
    const option = document.createElement("option")
    option.value = mp
    option.textContent = mp
    mpFilter.appendChild(option)
  })

  document.getElementById("kelasNilaiFilter")?.addEventListener("change", renderNilaiTable)
  document.getElementById("mataPelajaranFilter")?.addEventListener("change", renderNilaiTable)
}

function renderNilaiTable() {
  const kelas = document.getElementById("kelasNilaiFilter").value
  const mataPelajaran = document.getElementById("mataPelajaranFilter").value
  const tbody = document.getElementById("nilaiTbody")
  tbody.innerHTML = ""

  if (!kelas || !mataPelajaran) return

  const siswasInKelas = store.siswa.filter((s) => s.kelas === kelas)

  siswasInKelas.forEach((siswa) => {
    const nilaiData = store.nilai.find((n) => n.nis === siswa.nis && n.mataPelajaran === mataPelajaran)
    const nilai = nilaiData?.nilai || ""
    const grade = nilaiData ? getGrade(nilaiData.nilai) : ""

    const row = document.createElement("tr")
    row.innerHTML = `
            <td>${siswa.nama}</td>
            <td>${mataPelajaran}</td>
            <td>${nilai}</td>
            <td>${grade}</td>
            <td>
                <button class="edit-btn" onclick="editNilai('${siswa.nis}', '${mataPelajaran}')">Edit</button>
            </td>
        `
    tbody.appendChild(row)
  })
}

function getGrade(nilai) {
  nilai = Number.parseFloat(nilai)
  if (nilai >= 90) return "A"
  if (nilai >= 80) return "B"
  if (nilai >= 70) return "C"
  if (nilai >= 60) return "D"
  return "E"
}

function editNilai(nis, mataPelajaran) {
  const nilaiData = store.nilai.find((n) => n.nis === nis && n.mataPelajaran === mataPelajaran)
  const nilai = nilaiData?.nilai || ""

  const form = `
        <div class="form-group">
            <label>Nilai (0-100)</label>
            <input type="number" id="nilaiInput" min="0" max="100" value="${nilai}" required>
        </div>
        <div class="form-buttons">
            <button type="submit" class="btn btn-primary">Simpan</button>
            <button type="button" class="btn btn-secondary" onclick="closeModal()">Batal</button>
        </div>
    `

  showModal("Input Nilai", form, () => {
    const newNilai = Number.parseFloat(document.getElementById("nilaiInput").value)
    const existing = store.nilai.findIndex((n) => n.nis === nis && n.mataPelajaran === mataPelajaran)

    const data = { nis, mataPelajaran, nilai: newNilai }

    if (existing > -1) {
      store.nilai[existing] = data
    } else {
      store.nilai.push(data)
    }

    saveData()
    renderNilaiTable()
    closeModal()
  })
}

function openModalNilai() {
  const kelas = document.getElementById("kelasNilaiFilter").value
  const mataPelajaran = document.getElementById("mataPelajaranFilter").value

  if (!kelas || !mataPelajaran) {
    alert("Pilih kelas dan mata pelajaran terlebih dahulu")
    return
  }

  const siswasInKelas = store.siswa.filter((s) => s.kelas === kelas)

  let form = '<div class="form-group">'
  siswasInKelas.forEach((siswa) => {
    const nilaiData = store.nilai.find((n) => n.nis === siswa.nis && n.mataPelajaran === mataPelajaran)
    const nilai = nilaiData?.nilai || ""
    form += `
            <div style="margin-bottom: 10px;">
                <label>${siswa.nama}</label>
                <input type="number" min="0" max="100" value="${nilai}" class="siswa-nilai" data-nis="${siswa.nis}">
            </div>
        `
  })
  form += "</div>"
  form += `
        <div class="form-buttons">
            <button type="submit" class="btn btn-primary">Simpan Semua</button>
            <button type="button" class="btn btn-secondary" onclick="closeModal()">Batal</button>
        </div>
    `

  showModal("Input Nilai Massal", form, () => {
    document.querySelectorAll(".siswa-nilai").forEach((input) => {
      const nis = input.dataset.nis
      const nilai = Number.parseFloat(input.value) || 0
      const existing = store.nilai.findIndex((n) => n.nis === nis && n.mataPelajaran === mataPelajaran)

      if (existing > -1) {
        store.nilai[existing].nilai = nilai
      } else {
        store.nilai.push({ nis, mataPelajaran, nilai })
      }
    })

    saveData()
    renderNilaiTable()
    closeModal()
  })
}

// ==================== JADWAL ====================
function renderJadwalTable() {
  const kelas = document.getElementById("kelasJadwalFilter").value
  const tbody = document.getElementById("jadwalTbody")
  tbody.innerHTML = ""

  const filteredJadwal = store.jadwal.filter((j) => !kelas || j.kelas === kelas)

  if (filteredJadwal.length === 0) {
    tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 20px;">Belum ada jadwal</td></tr>'
    return
  }

  filteredJadwal.forEach((jadwal, idx) => {
    const row = document.createElement("tr")
    row.innerHTML = `
            <td>${jadwal.hari}</td>
            <td>${jadwal.jam}</td>
            <td>${jadwal.mataPelajaran}</td>
            <td>${jadwal.guru}</td>
            <td>${jadwal.ruangan}</td>
            <td>
                <div class="action-buttons">
                    <button class="edit-btn" onclick="editJadwal(${idx})">Edit</button>
                    <button class="delete-btn" onclick="deleteJadwal(${idx})">Hapus</button>
                </div>
            </td>
        `
    tbody.appendChild(row)
  })
}

function openModalJadwal(idx = null) {
  const title = idx !== null ? "Edit Jadwal" : "Tambah Jadwal"
  const jadwal =
    idx !== null ? store.jadwal[idx] : { hari: "", jam: "", mataPelajaran: "", guru: "", ruangan: "", kelas: "" }

  const hari = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat"]
  const form = `
        <div class="form-group">
            <label>Hari</label>
            <select id="hari" required>
                <option value="">Pilih Hari</option>
                ${hari.map((h) => `<option value="${h}" ${jadwal.hari === h ? "selected" : ""}>${h}</option>`).join("")}
            </select>
        </div>
        <div class="form-group">
            <label>Jam Mulai</label>
            <input type="time" id="jam" value="${jadwal.jam}" required>
        </div>
        <div class="form-group">
            <label>Mata Pelajaran</label>
            <select id="mataPelajaran" required>
                <option value="">Pilih Mata Pelajaran</option>
                ${[...new Set(store.guru.map((g) => g.mataPelajaran))]
                  .map((mp) => `<option value="${mp}" ${jadwal.mataPelajaran === mp ? "selected" : ""}>${mp}</option>`)
                  .join("")}
            </select>
        </div>
        <div class="form-group">
            <label>Guru</label>
            <select id="guru" required>
                <option value="">Pilih Guru</option>
                ${store.guru.map((g) => `<option value="${g.nama}" ${jadwal.guru === g.nama ? "selected" : ""}>${g.nama}</option>`).join("")}
            </select>
        </div>
        <div class="form-group">
            <label>Kelas</label>
            <select id="kelas" required>
                <option value="">Pilih Kelas</option>
                ${store.kelas.map((k) => `<option value="${k.nama}" ${jadwal.kelas === k.nama ? "selected" : ""}>${k.nama}</option>`).join("")}
            </select>
        </div>
        <div class="form-group">
            <label>Ruangan</label>
            <input type="text" id="ruangan" value="${jadwal.ruangan}" required>
        </div>
        <div class="form-buttons">
            <button type="submit" class="btn btn-primary">Simpan</button>
            <button type="button" class="btn btn-secondary" onclick="closeModal()">Batal</button>
        </div>
    `

  showModal(title, form, () => {
    const newJadwal = {
      hari: document.getElementById("hari").value,
      jam: document.getElementById("jam").value,
      mataPelajaran: document.getElementById("mataPelajaran").value,
      guru: document.getElementById("guru").value,
      kelas: document.getElementById("kelas").value,
      ruangan: document.getElementById("ruangan").value,
    }

    if (idx !== null) {
      store.jadwal[idx] = newJadwal
    } else {
      store.jadwal.push(newJadwal)
    }
    saveData()
    renderJadwalTable()
    closeModal()
  })
}

function editJadwal(idx) {
  openModalJadwal(idx)
}

function deleteJadwal(idx) {
  if (confirm("Yakin ingin menghapus jadwal ini?")) {
    store.jadwal.splice(idx, 1)
    saveData()
    renderJadwalTable()
  }
}

// ==================== MODAL HANDLERS ====================
function showModal(title, formHTML, onSubmit) {
  document.getElementById("modalTitle").textContent = title
  document.getElementById("modalForm").innerHTML = formHTML
  document.getElementById("modal").classList.add("show")

  document.getElementById("modalForm").onsubmit = (e) => {
    e.preventDefault()
    onSubmit()
  }
}

function closeModal() {
  document.getElementById("modal").classList.remove("show")
  document.getElementById("modalForm").innerHTML = ""
}

// ==================== FORM HANDLER ====================
function handleFormSubmit(e) {
  e.preventDefault()
}

// ==================== DATE TIME ====================
function updateDateTime() {
  const now = new Date()
  const options = {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }
  document.getElementById("dateTime").textContent = now.toLocaleDateString("id-ID", options)
}

// ==================== LOGOUT ====================
function logout() {
  if (confirm("Yakin ingin logout?")) {
    localStorage.removeItem("userInfo")
    window.location.href = "login.html"
  }
}

// ==================== LOCAL STORAGE FUNCTIONS ====================
function saveToLocalStorage() {
  localStorage.setItem("schoolData", JSON.stringify(store))
}
